#### Preamble ####
# Purpose: Replicated graphs from... [...UPDATE THIS...]
# Author: Joyce Lin, Aliza Mithwani, Betty Liu, Manjun Zhu
# Date: 19 September 2024
# License: MIT
# Pre-requisites: [...UPDATE THIS...]
# Any other information needed? [...UPDATE THIS...]


#### Workspace setup ####
library(tidyverse)
# [...UPDATE THIS...]

#### Load data ####
# [...ADD CODE HERE...]



